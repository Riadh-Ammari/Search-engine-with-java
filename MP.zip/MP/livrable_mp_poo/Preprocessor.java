package com.haddad.readers;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Preprocessor implements DeleteEmptyWords {
    @Override
    public List<String> DeleteEmptyWords(Document document) {
        String content = document.getContent();
        String[] words = content.split("\\s+");
        List<String> result = new ArrayList<>();
        List<String> unnecessary= Arrays.asList("of","or","a","and",".",",",";","","?","!",":" );
        for(String word : words){
            if(!unnecessary.contains(word.toLowerCase())){
                result.add(word.toLowerCase());
            }
        }
        return result;
    }

    public List<String> getContentPretraite(Document document) {
        return DeleteEmptyWords(document);
    }
}
