package com.haddad.readers;

import java.util.List;

public class main {
    public static void main(String[] args) {
        Document document = new Document("C:\\Users\\amari\\OneDrive\\Desktop\\MP\\tres_petit_corpus\\10.txt");

        // Obtenir et afficher le contenu du document
        String content = document.getContent();
        System.out.println("Contenu du document :");
        System.out.println(content);
        Preprocessor preprocessor = new Preprocessor();
        List<String> preprocessor1=preprocessor.getContentPretraite( document);
        System.out.println("Contenu du document pretraite :");
        for (String word : preprocessor1) {
            System.out.print(word + " ");
        }
        Analyzor analyzor=new Analyzor();
        System.out.println("Contenu du document analyse :");
        List<Statistic> test= analyzor.analyse(preprocessor,document);
        for(Statistic statistic :test){
            System.out.println(""+statistic.getWord()+":"+statistic.getStatistique());


        }



    }

}
