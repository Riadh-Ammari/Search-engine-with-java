package com.haddad.readers;

import java.util.*;

public class Analyzor implements OccNomber{

    @Override
    public List<Statistic> analyse(Preprocessor preprocessor,Document document) {
        List<Statistic> result= new ArrayList<>();
        List<String> contentPretraite = preprocessor.getContentPretraite(document);
        Map<String, Integer> stat = new TreeMap<>();
        for(String word : contentPretraite){
            int occurrenceNumber=0;
            for (String mot : contentPretraite) {
                if (word.equals(mot)) {
                    occurrenceNumber++;
                }
            }
            stat.put(word,occurrenceNumber);
        }
        for(Map.Entry<String, Integer> dic : stat.entrySet()){
            String key = dic.getKey();
            int value = dic.getValue();
            result.add(new Statistic(key, value));
        }

        return result;
    }
}
