package com.haddad.readers;

import java.util.List;

public interface DocumentReader {
	
	List<String> readDocument(String path);

}
