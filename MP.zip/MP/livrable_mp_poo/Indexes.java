package com.haddad.readers;

public class Indexes {
}
