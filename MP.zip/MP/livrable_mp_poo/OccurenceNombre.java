package com.haddad.readers;

public interface OccurenceNombre {
    int calculOccurence(Preprocessor preprocessor);
}
