package com.haddad.readers;

import java.util.List;

public interface DeleteEmptyWords {
    List<String> DeleteEmptyWords(Document document);
}
