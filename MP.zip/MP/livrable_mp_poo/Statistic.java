package com.haddad.readers;

public class Statistic {
    private String word;
    private int statistique;

    public Statistic(String word,int statistique){
        this.word = word;
        this.statistique = statistique;
    }

    public int getStatistique() {
        return statistique;
    }

    public String getWord() {
        return word;
    }
}
