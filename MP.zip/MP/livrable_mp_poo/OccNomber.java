package com.haddad.readers;

import java.util.List;

public interface OccNomber {
    List<Statistic> analyse(Preprocessor preprocessor,Document document );

}
