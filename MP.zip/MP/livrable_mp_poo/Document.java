package com.haddad.readers;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class Document {
    private String path;
    private String content;

    public Document(String path) {
        this.path = path;
        this.content = lireContenu();
    }

    private String lireContenu() {
        StringBuilder sb = new StringBuilder();
        try (BufferedReader br = new BufferedReader(new FileReader(path))) {
            String line;
            while ((line = br.readLine()) != null) {
                sb.append(line).append("\n");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return sb.toString();
    }


    public String getPath() {
        return path;
    }


    public String getContent() {
        return content;
    }
}
